function Navigate_To_Grandma_Streams(){
    document.getElementById('MediaPlayer').src = 'http://www.grandma.press';
}

function Navigate_To_GoatTV(){
	document.getElementById('MediaPlayer').src = 'https://www.goatdee.net';
}

function Navigate_To_SportsHD(){
	document.getElementById('MediaPlayer').src = 'http://www.sportshd.me/nfl'
}

function Navigate_To_FSGo(){
	document.getElementById('MediaPlayer').src = 'http://www.foxsportsgo.com/';
}

function Navigate_To_CTSN(){
	document.getElementById('MediaPlayer').src = 'https://tunein.com/radio/Alabama-Crimson-Tide-Sports-Network-s231150/';
}

function Navigate_To_ATSN(){
	document.getElementById('MediaPlayer').src = 'https://tunein.com/radio/Auburn-Tigers-Sports-Network-s230231';
}

function Navigate_To_SportsRFree(){
	document.getElementById('MediaPlayer').src = 'https://sportsrfree.me/';
}

function Navigate_To_NFLNet(){
	document.getElementById('MediaPlayer').src = 'http://www.Genti.Stream/hd/nfl.php';
}

function Navigate_To_FoodNet(){
	document.getElementById('MediaPlayer').src = 'http://watch.foodnetwork.com/live.html';
}

function Navigate_To_EarthCam(){
	document.getElementById('MediaPlayer').src = 'http://www.earthcam.com/';
}

function Navigate_To_ISSLive(){
	document.getElementById('MediaPlayer').src = 'http://www.n2yo.com/space-station/';
}